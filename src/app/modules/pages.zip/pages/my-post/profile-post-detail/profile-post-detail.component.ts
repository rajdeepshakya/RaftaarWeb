import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-post-detail',
  templateUrl: './profile-post-detail.component.html',
  styleUrls: ['./profile-post-detail.component.scss']
})
export class ProfilePostDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
