import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-market-buba-puppet-lamp',
  templateUrl: './market-buba-puppet-lamp.component.html',
  styleUrls: ['./market-buba-puppet-lamp.component.scss']
})
export class MarketBubaPuppetLampComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
