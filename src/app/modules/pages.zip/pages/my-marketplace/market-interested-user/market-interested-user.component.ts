import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-market-interested-user',
  templateUrl: './market-interested-user.component.html',
  styleUrls: ['./market-interested-user.component.scss']
})
export class MarketInterestedUserComponent implements OnInit {
  users=[
    {

    },
    {
      
    }
  ]
  constructor() { }

  ngOnInit(): void {
  }

}
