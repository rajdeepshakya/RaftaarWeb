import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-arrivals',
  templateUrl: './new-arrivals.component.html',
  styleUrls: ['./new-arrivals.component.scss']
})
export class NewArrivalsComponent implements OnInit {
  cards=[
    {
    heading:'Packaging'
  },
  {
    heading:'Printing'
  },
  {
    heading:'Civil & Construction'
  },
  {
    heading:'Packaging'
  },
  
  ]
  constructor() { }

  ngOnInit(): void {
  }

}
