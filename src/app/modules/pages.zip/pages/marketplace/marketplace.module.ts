import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MarketplaceRoutingModule } from './marketplace-routing.module';
import { MarketFrontPageComponent } from './market-front-page/market-front-page.component';
import { AddNewProductComponent } from './add-new-product/add-new-product.component';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { SarvayogastudioComponent } from './sarvayogastudio/sarvayogastudio.component';
import { RequestRaftaarrVerificationComponent } from './request-raftaarr-verification/request-raftaarr-verification.component';
import { LayoutModule } from 'src/app/layout/layout.module';
import {MatSliderModule} from '@angular/material/slider';
import { PopularProductComponent } from './popular-product/popular-product.component';
import { NewArrivalsComponent } from './new-arrivals/new-arrivals.component';
import { BestSellerProductsComponent } from './best-seller-products/best-seller-products.component';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    MarketFrontPageComponent,
    AddNewProductComponent,
    SarvayogastudioComponent,
    RequestRaftaarrVerificationComponent,
    PopularProductComponent,
    NewArrivalsComponent,
    BestSellerProductsComponent
  ],
  imports: [
    CommonModule,
    MarketplaceRoutingModule,
    MatSelectModule,
    MatFormFieldModule,
    LayoutModule,
    MatSliderModule,
    ReactiveFormsModule

  ],
  exports: [MarketFrontPageComponent,SarvayogastudioComponent],
  entryComponents:[
   MarketFrontPageComponent,SarvayogastudioComponent
  ]
})
export class MarketplaceModule { }
