import { Component, OnInit } from '@angular/core';
import { PostPublishComponent } from 'src/app/shared/dialogs/post-publish/post-publish.component';
import { MatDialog } from '@angular/material/dialog';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ApiServicesService } from 'src/app/services/apiServices/api-services.service';
// import * as S3 from 'aws-sdk/clients/s3';
import { environment } from 'src/environments/environment';
import { UploadService } from 'src/app/services/upload.service';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { ToastrService } from 'ngx-toastr';
import { API_ROUTES } from 'src/app/core/_constants/api-route.constant';
import { AddFieldComponent } from 'src/app/shared/dialogs/add-field/add-field.component';
import { ActivatedRoute, Router } from '@angular/router';
import { EditPopupComponent } from 'src/app/shared/dialogs/edit-popup/edit-popup.component';

@Component({
  selector: 'app-add-new-product',
  templateUrl: './add-new-product.component.html',
  styleUrls: ['./add-new-product.component.scss']
})
export class AddNewProductComponent implements OnInit {
  addForm: FormGroup;
  submitted = false;
  catagory:any
  data: any;
  instrudata: any;
  subCatagory: any;
  industry: any;
  id: any;
  catagoryId: any;
  constructor(private activeRoute:ActivatedRoute,private dialog:MatDialog,private fb:FormBuilder,private service:ApiServicesService) { 
    this.addForm=this.fb.group({
      category1_id:['']
    })
  }

  ngOnInit(): void {
    this.activeRoute.queryParams.subscribe((params) =>{
      this.catagoryId = params?.['id'];
      // console.log(this.machineId)
     
    })
    this.getSubCatagory()
    this.getIndustry()

  }
  openpostModal(){
    const dialogRef = this.dialog.open(EditPopupComponent, {
      maxHeight: '100vh',
      width:'465px',
      panelClass:'yespost',
      data: {
        img:'../.assets/images/Icon.png',
        heading:'Are you sure you want to post this project?',
        para:'Lorem Ipsum is simply dummy text of the printing text of the printing. ',
        report:'Back',
        cancel:'Yes, Post'
      }
    });
  }
  get f() { return this.addForm.controls; }
  onSubmit(post:any){
    this.submitted = true;
   
  if (this.addForm.valid) {
    console.log(post,"addProjects")
    this.service.post({},`${API_ROUTES.Projects.createProjects}`,post).pipe().subscribe(response => {
      if (response.success) {
        alert('Success')
       
      } 
    })
  }
  }
  getSubCatagory(){
    this.service.get({},`${API_ROUTES.Marketplace.catagory_1}`).pipe().subscribe((res)=>{
      this.subCatagory = res.result.rows;
      console.log(this.subCatagory)
    })
  }
  getIndustry(){
    this.service.get({category1_id:this.catagoryId},`${API_ROUTES.Marketplace.catagory_2}`).pipe().subscribe((res)=>{
      this.industry = res.result.rows;
      console.log(this.industry)
    })
  }
fix(id: any) {
  console.log(id.target.value);
  this.addForm.value.category1_id =id;
  
}
}