import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-best-seller-products',
  templateUrl: './best-seller-products.component.html',
  styleUrls: ['./best-seller-products.component.scss']
})
export class BestSellerProductsComponent implements OnInit {
  cards=[
    {
    heading:'Packaging'
  },
  {
    heading:'Printing'
  },
  {
    heading:'Civil & Construction'
  },
  {
    heading:'Packaging'
  },
  
  ]
  constructor() { }

  ngOnInit(): void {
  }

}
