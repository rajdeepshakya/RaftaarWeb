import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-popular-product',
  templateUrl: './popular-product.component.html',
  styleUrls: ['./popular-product.component.scss']
})
export class PopularProductComponent implements OnInit {
cards=[
  {
  heading:'Packaging'
},
{
  heading:'Printing'
},
{
  heading:'Civil & Construction'
},
{
  heading:'Packaging'
},

]
  constructor() { }

  ngOnInit(): void {
  }

}
