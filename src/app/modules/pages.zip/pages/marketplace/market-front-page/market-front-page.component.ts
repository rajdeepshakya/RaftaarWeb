import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { FilterProductComponent } from 'src/app/shared/dialogs/filter-product/filter-product.component';

@Component({
  selector: 'app-market-front-page',
  templateUrl: './market-front-page.component.html',
  styleUrls: ['./market-front-page.component.scss']
})
export class MarketFrontPageComponent implements OnInit {
  cards=[
    {
    heading:'Packaging'
  },
  {
    heading:'Printing'
  },
  {
    heading:'Civil & Construction'
  },

  
  ]
  formatLabel(value: number) {
    if (value >= 1000) {
      return Math.round(value / 1000) + 'k';
    }

    return value;
  }
  constructor() { }

  ngOnInit(): void {
  }

}
