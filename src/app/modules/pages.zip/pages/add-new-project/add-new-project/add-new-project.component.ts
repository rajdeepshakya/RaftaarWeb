import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { API_ROUTES } from 'src/app/core/_constants/api-route.constant';
import { ApiServicesService } from 'src/app/services/apiServices/api-services.service';
import { EditPopupComponent } from 'src/app/shared/dialogs/edit-popup/edit-popup.component';
import { environment } from 'src/environments/environment';
import { UploadService } from 'src/app/services/upload.service';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { ToastrService } from 'ngx-toastr';
import {MAT_MOMENT_DATE_ADAPTER_OPTIONS, MAT_MOMENT_DATE_FORMATS, MomentDateAdapter} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';
import * as _moment from 'moment';
import {default as _rollupMoment} from 'moment';
import { DatePipe } from "@angular/common";

@Component({
  selector: 'app-add-new-project',
  templateUrl: './add-new-project.component.html',
  styleUrls: ['./add-new-project.component.scss'],

})
export class AddNewProjectComponent implements OnInit {
  projectForm:FormGroup;
  machine:any=['Select Machine','Machine 1']
  instrument:any=['Select Instrument','Instrument 1']
  submitted:boolean=false;
  imageUrl: any;
  imageName: any
  selectDummyUserId: any;
  data: any;
countnumber:any="";
Media:any=[];
Highlights:any[];
instrudata: any;
constructor(public datepipe:DatePipe, private fb:FormBuilder, private dialog:MatDialog,private service:ApiServicesService,private router :Router,
  public upload: UploadService,private loader:NgxUiLoaderService,private toastr:ToastrService) { }

files:any = [];
ngOnInit(): void {
  this.getIndustry()
  this.createForm();
}
get f() { return this.projectForm.controls; }

 /**createForm*/
 createForm() {
  this.submitted = false;
  this.projectForm = this.fb.group({
    title:['',[Validators.required]],
    description:['',[Validators.required]],
    customer_name:['',[Validators.required]],
    enter_quantity:['',[Validators.required]],
    instruments:['',[Validators.required]],
    project_start_date:['',Validators.required],
    project_end_date:['',Validators.required] ,
    is_live:['',[Validators.required]] ,
    machine_id:['',[Validators.required]],
    instrument_id:['',[Validators.required]],
    is_starred:['',[Validators.required]],
    highlights:['',[Validators.required]],
    media:['',[Validators.required]]

   })

}
  onSubmit(post:any){
    var requestBody= {
      media:  this.Media,
      highlights:[{
        highlight_desc:post.highlights
      }],
      title:  post.title,
      description: post.description,
      customer_name:post.customer_name,
      enter_quantity:post.enter_quantity,
      instruments:post.instrument,
      project_start_date:post.project_start_date,
      project_end_date:post.project_end_date ,
      is_live:post.is_live ,
      machine_id:post.machine_id,
      instrument_id:post.instrument_id,
      is_starred:post.is_starred,
      
  }
 
    this.submitted = true;
    console.log(post,"addProjects")
    let projectDate=this.datepipe.transform(post.project_start_date,'yyyy/MM/dd');
    post.project_start_date=projectDate
    let projectendDate=this.datepipe.transform(post.project_end_date,'yyyy/MM/dd');
    post.project_end_date=projectendDate
    this.service.post(requestBody,`${API_ROUTES.Projects.createProjects}`,post).pipe().subscribe(response => {
      if (response.success) {
        alert('Success')
        let id=response.result.project.id
        this.router.navigate(['/main/profile/projects'],{queryParams:{id:id}})
        this.resetFrom();
      }
    })
  

  }
  getIndustry(){
    const params = {
      pageNO : 1,
      size : 5,
      type : 'machine'
    }
    this.service.get(params,`${API_ROUTES.Machine.machineList}`).pipe().subscribe((res)=>{
      this.data = res.result;
      console.log(this.data)
    })
    const instrudata = {
      pageNO : 1,
      size : 5,
      type : 'instrument'
    }
    this.service.get(instrudata,`${API_ROUTES.Machine.instrumentList}`).pipe().subscribe((res)=>{
      this.instrudata = res.result;
      console.log(this.instrudata)
    })
  }
  
  fix(id: any) {
    console.log(id.target.value);
    this.projectForm.value.machine_id =id;
    this.projectForm.value.industry_id=id;
    
  }

fileupload(e: any,data:any) {
  
  if(this.files.length >5){
    this.toastr.error("More than 5 files are not allowed")
  }
  else {
    if(this.files.length > 0 && (this.files.length + parseInt(e.target.files.length) > 5)){
      this.toastr.error("More than 5 files are not allowed")
    }
    else{
      if(e.target.files.length>1){
        for(let i=0; i<e.target.files.length;i++){
          this.uploadFile(e.target.files[i],data)
        }
       
      }
      else{
        const selectedFile = e.target.files[0];
        this.uploadFile(selectedFile,data);
       
      }
    }
  }
  return false;

}

async uploadFile(selectedFile : any,fileTypa:any){
  let uploadedImage:any = await this.upload.uploadFile(selectedFile);
    if (uploadedImage) {
      if(fileTypa==1){
        this.Media.push({
          url:uploadedImage.Location,
          media_type: "Image",
        })
      }else if(fileTypa==2){
        this.Media.push( {
          url:uploadedImage.Location,
          media_type: "video",
        })
      }else if(fileTypa==3){
        this.Media.push( {
          url:uploadedImage.Location,
          media_type: "pdf",
        })
      }
     
      console.log(uploadedImage);
      this.files.push(uploadedImage);
      
      return true;
    } else {

      return false;
    }
}

/**resetFrom*/
resetFrom() {
  
  this.submitted = false;
  this.projectForm.reset();
}
onFileDropped(file:any) {
      for(let i =0;i <file.length;i++){
        this.files.push(file[i].name);
      }
      console.log(this.files);
      
    }
    selectUser(val: any) {
      if (this.selectDummyUserId.includes(val)) {
        this.selectDummyUserId.splice(this.selectDummyUserId.indexOf(val), 1)
        console.log(this.selectDummyUserId);
            }
      else {
        this.selectDummyUserId.push(val)
        console.log(this.selectDummyUserId)
      }
    }
}
