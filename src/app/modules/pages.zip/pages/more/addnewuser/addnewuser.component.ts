import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { API_ROUTES } from 'src/app/core/_constants/api-route.constant';
import { ApiServicesService } from 'src/app/services/apiServices/api-services.service';

@Component({
  selector: 'app-addnewuser',
  templateUrl: './addnewuser.component.html',
  styleUrls: ['./addnewuser.component.scss']
})
export class AddnewuserComponent implements OnInit {
counternumber:any="";
contentform:any;
submitted: boolean = false;
  loginForm: any;
  constructor(private fb:UntypedFormBuilder, private service:ApiServicesService,private router :Router) { }

  ngOnInit(): void {
    this.loginForm=this.fb.group({
      username:['',Validators.required],
      email:['',Validators.required],
      phone_no:[Number(''),Validators.required],
      designation:['',Validators.required],
      profile_pic:['www.pic']


     
    })
  }

  onSubmit(post:any) {
    console.log(post,"signup")
    this.submitted = true;
    this.service.post(post,`${API_ROUTES.More.addUser}`,{}).pipe().subscribe((res)=>{
      if(res.success_code==201){
        alert("User Added Successfully")
        this.router.navigate(['/main/more/view-user-detail'])
      }
    })
    
  }
  get f() { return this.loginForm.controls; }

}
