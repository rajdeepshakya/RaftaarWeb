import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-saved',
  templateUrl: './saved.component.html',
  styleUrls: ['./saved.component.scss']
})
export class SavedComponent implements OnInit {
  cards=[
    {
    heading:'Unisense Digital Agency',
    min:'Jan 22, 2022 at 1:30 PM',
    para:"Boxboard is a simple and beautiful admin template with tons of flexible components",
   interest:'Show Interests',
   unSave:'Unsave',
   share:'105 Share',
   img:'../../.assets/images/img1.svg'
  },
  {
    heading:'Unisense Digital Agency',
    min:'Jan 22, 2022 at 1:30 PM',
    para:"Boxboard is a simple and beautiful admin template with tons of flexible components",
   interest:'Show Interests',
   unSave:'Unsave',
   share:'105 Share',
   img:'../../.assets/images/img2.svg'
  },
  {
    heading:'Unisense Digital Agency',
    min:'Jan 22, 2022 at 1:30 PM',
    para:"Boxboard is a simple and beautiful admin template with tons of flexible components",
   interest:'Show Interests',
   unSave:'Unsave',
   share:'105 Share',
   img:'../../.assets/images/img3.svg'
  },
  ]
  isShow=false
  constructor() { }
  showdropdown(){
    this.isShow=!this.isShow
  }
  ngOnInit(): void {
  }

}
