import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder } from '@angular/forms';
import { API_ROUTES } from 'src/app/core/_constants/api-route.constant';
import { ApiServicesService } from 'src/app/services/apiServices/api-services.service';
import {COMMA, ENTER} from '@angular/cdk/keycodes';
import { ElementRef, ViewChild} from '@angular/core';
import {UntypedFormControl} from '@angular/forms';
import {MatAutocompleteSelectedEvent} from '@angular/material/autocomplete';
import {MatChipInputEvent} from '@angular/material/chips';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';
@Component({
  selector: 'app-interests',
  templateUrl: './interests.component.html',
  styleUrls: ['./interests.component.scss']
})
export class InterestsComponent implements OnInit {
  selectDummyUserId: any = []
  selectUserId: any = []
  interestName:any;
  loginForm: any;

  separatorKeysCodes: number[] = [ENTER, COMMA];
  fruitCtrl = new UntypedFormControl('');
  filteredFruits: Observable<string[]>;
  fruits: string[] = ['Lemon'];
  allFruits: string[] = ['Apple', 'Lemon', 'Lime', 'Orange', 'Strawberry'];

  @ViewChild('fruitInput') fruitInput:any;
  constructor(private service:ApiServicesService, private fb:UntypedFormBuilder) {
    this.filteredFruits = this.fruitCtrl.valueChanges.pipe(
      startWith(null),
      map((fruit: string | null) => (fruit ? this._filter(fruit) : this.allFruits.slice())),
    );
   }
   add(event: any): void {
    const value = (event.value || '').trim();

    // Add our fruit
    if (value) {
      this.fruits.push(value);
    }

    // Clear the input value
    event.chipInput!.clear();

    this.fruitCtrl.setValue(null);
  }

  remove(fruit: string): void {
    const index = this.fruits.indexOf(fruit);

    if (index >= 0) {
      this.fruits.splice(index, 1);
    }
  }

  selected(event:any): void {
    this.fruits.push(event.option.viewValue);
    this.fruitInput.nativeElement.value = '';
    this.fruitCtrl.setValue(null);
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.allFruits.filter(fruit => fruit.toLowerCase().includes(filterValue));
  }
  ngOnInit(): void {
    this.onGetInterest();
    this.loginForm = this.fb.group({
      interest: [this.selectDummyUserId],
      // lorem:[this.selectDummyUserId],
      // duration:[this.selectDummyUserId],

    });

    
  }
  onVerify(post:any){
    this.service.post(post,`${API_ROUTES.Account.chooseInterest}`,{}).pipe().subscribe((res)=>{
      if(res.success_code==200){
        alert("Interest Added Successfully")
      }
    })
  }
  
  onGetInterest(){
    this.service.get({},`${API_ROUTES.Account.getInterest}`).pipe().subscribe((res)=>{
      this.interestName = res.result
    })
  }
  selectUser(val: any) {
    if (this.selectDummyUserId.includes(val)) {
      this.selectDummyUserId.splice(this.selectDummyUserId.indexOf(val), 1)
      console.log(this.selectDummyUserId);
      
      // this.selectUserId.splice(this.selectUserId.findIndex((v: any) => v.id === val), 1)
    }
    else {
     
      this.selectDummyUserId.push(val)
      // this.selectUserId.push({ 'id': val, 'priority': false })
      console.log(this.selectDummyUserId)
    }
  }
}
