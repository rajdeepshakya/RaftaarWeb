import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { API_ROUTES } from 'src/app/core/_constants/api-route.constant';
import { ApiServicesService } from 'src/app/services/apiServices/api-services.service';

@Component({
  selector: 'app-editprofile',
  templateUrl: './editprofile.component.html',
  styleUrls: ['./editprofile.component.scss']
})
export class EditprofileComponent implements OnInit {
  counternumber:any="";
  contentform:any;
  itras:any=['name','surname'];
  submitted: boolean = false;
  constructor(private fb :UntypedFormBuilder, private router:Router, private service:ApiServicesService) { }

  ngOnInit(): void {
    this.contentform = this.fb.group({
      company_name:['',Validators.required],
      description:['',Validators.required],
      gst_no:['',Validators.required]
     });
     
  }
  onSubmit(post:any) {
    this.submitted = true;
    this.service.put(post,{},`${API_ROUTES.More.editProfile}`).pipe().subscribe((res)=>{
      console.log(res)
      if(res.success_code=201){
      alert(res.result)
       
        
      }
    })
    
  }

}
