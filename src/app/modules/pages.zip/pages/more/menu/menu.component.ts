import { Component, OnInit } from '@angular/core';
import { API_ROUTES } from 'src/app/core/_constants/api-route.constant';
import { ApiServicesService } from 'src/app/services/apiServices/api-services.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.scss']
})
export class MenuComponent implements OnInit {
  companyProfile:any;
  constructor( private service: ApiServicesService) { }

  ngOnInit(): void {
    this.getHomeList();

  }

  getHomeList(){
    this.service.get({},`${API_ROUTES.More.moreDetails}`).pipe().subscribe((res)=>{
      this.companyProfile = res.result;
      console.log(this.companyProfile)
    })
  }


}
