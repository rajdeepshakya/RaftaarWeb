import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AddNewComponent } from 'src/app/shared/dialogs/add-new/add-new.component';
import { API_ROUTES } from 'src/app/core/_constants/api-route.constant';
import { ApiServicesService } from 'src/app/services/apiServices/api-services.service';
import { AddPostComponent } from 'src/app/shared/dialogs/add-post/add-post.component';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-chat-user-list',
  templateUrl: './chat-user-list.component.html',
  styleUrls: ['./chat-user-list.component.scss']
})
export class ChatUserListComponent implements OnInit {
userList:any;
@Input() img = "";
  @Input() customClass="";
  // @Input() title = "Card Title";
  @Input() student:any;
  @Input() companyName:any;
  @Input() adminName:any;
  @Input() messages = 'messages';
  @Input() unmatched: boolean = false;

  @Input() user_type = "user_type";
  @Output() sendData = new EventEmitter();
  status:any
  constructor(private dialog:MatDialog , 
    private service: ApiServicesService,
    private router:Router,
    private toastr:ToastrService
    ) { }

  ngOnInit(): void {
    this. getIntrestedUserList();
    setTimeout((x)=>{
      console.log(this.student, this.companyName, this.adminName)

    },2000)
  }
  getIntrestedUserList(){
    debugger
    var req={
      req_id:'9a388659-1e3b-4818-8d95-a7145007d42c'
    }
    this.service.get(req,`${API_ROUTES.chat.intrestedUserList}`).pipe().subscribe((res)=>{
      debugger
      if(res.success){
        this.userList = res.result;
      }else{

      }
     
      // if(res.result.Post!=null){
      //   this.data = res.result.Post;
      //   console.log(this.data,"dfghjkl");
      // }else if(res.result.Requirement!=null)
      // {
      //   this.data = res.result.Requirement;
      // }
      
    }
    )
  }
  sendId(obj:any,type:any){
    this.sendData.emit(obj)
    console.log(obj)
    this.status = type
  }
}
