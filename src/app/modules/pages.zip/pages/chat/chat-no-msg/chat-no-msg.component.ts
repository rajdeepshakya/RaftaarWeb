import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chat-no-msg',
  templateUrl: './chat-no-msg.component.html',
  styleUrls: ['./chat-no-msg.component.scss']
})
export class ChatNoMsgComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
