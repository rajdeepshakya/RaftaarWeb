import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { API_ROUTES } from 'src/app/core/_constants/api-route.constant';
import { ApiServicesService } from 'src/app/services/apiServices/api-services.service';
import { UploadService } from 'src/app/services/upload.service';
import { EditPopupComponent } from 'src/app/shared/dialogs/edit-popup/edit-popup.component';

@Component({
  selector: 'app-add-new-featured-product',
  templateUrl: './add-new-featured-product.component.html',
  styleUrls: ['./add-new-featured-product.component.scss']
})
export class AddNewFeaturedProductComponent implements OnInit {

countnumber:any="";
contentform:any;
myForm: FormGroup;
submitted = false;
Media:any=[];
Highlights:any[]
constructor(private fb:FormBuilder,
  private dialog :MatDialog,
  public upload: UploadService,
  private toastr:ToastrService,
  private service:ApiServicesService,
  private router: Router,
  ) { }

files:any = [];
ngOnInit(): void {
  // this.contentform = this.fb.group({
  //   number:['',Validators.required]

  //  });
  this.createForm();
}
get f() { return this.myForm.controls; }
 /**createForm*/
 createForm() {
  this.submitted = false;
  this.myForm = this.fb.group({
    title: ['', [Validators.required]],
    description: ['', [Validators.required]],
    highlights:['',[Validators.required]],

   })

}
  onSubmit(data:any){
   
    var requestBody= {
      media:this.Media,
      highlights:[{
        highlight_desc:data.highlights
      }],
      title:  data.title,
      description: data.description,
  }
 
    this.submitted = true;
   
  if (this.myForm.valid) {

    this.service.post(requestBody,`${API_ROUTES.Product.addProduct}`,data).pipe().subscribe(response => {
      if (response.success) {
        alert("Success");
        let id=response.result.id
        this.router.navigate(['/main/profile/products'],{queryParams:{id:id}})
        this.resetFrom();
      }
       else {
        alert("invalid");
  }
})
}
}
  

fileupload(e: any,data:any) {
  
  if(this.files.length >5){
    this.toastr.error("More than 5 files are not allowed")
  }
  else {
    if(this.files.length > 0 && (this.files.length + parseInt(e.target.files.length) > 5)){
      this.toastr.error("More than 5 files are not allowed")
    }
    else{
      if(e.target.files.length>1){
        for(let i=0; i<e.target.files.length;i++){
          this.uploadFile(e.target.files[i],data)
        }
       
      }
      else{
        const selectedFile = e.target.files[0];
        this.uploadFile(selectedFile,data);
       
      }
    }
  }
  return false;

}

async uploadFile(selectedFile : any,fileTypa:any){
  let uploadedImage:any = await this.upload.uploadFile(selectedFile);
    if (uploadedImage) {
      if(fileTypa==1){
        this.Media.push({
          url:uploadedImage.Location,
          media_type: "Image",
        })
      }else if(fileTypa==2){
        this.Media.push({
          url:uploadedImage.Location,
          media_type: "video",
        })
      }else if(fileTypa==3){
        this.Media.push({
          url:uploadedImage.Location,
          media_type: "pdf",
        })
      }
     
      console.log(uploadedImage);
      this.files.push(uploadedImage);
      
      return true;
    } else {

      return false;
    }
}

/**resetFrom*/
resetFrom() {
  
  this.submitted = false;
  this.myForm.reset();
}
onFileDropped(file:any) {
      for(let i =0;i <file.length;i++){
        this.files.push(file[i].name);
      }
      console.log(this.files);
      
    }
    
    
}
