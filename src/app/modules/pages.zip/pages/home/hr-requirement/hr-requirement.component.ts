import { Component, OnInit } from '@angular/core';
import { PostPublishComponent } from 'src/app/shared/dialogs/post-publish/post-publish.component';
import { MatDialog } from '@angular/material/dialog';
import { UntypedFormArray, UntypedFormBuilder, Validators } from '@angular/forms';
import { ApiServicesService } from 'src/app/services/apiServices/api-services.service';
import {MAT_MOMENT_DATE_ADAPTER_OPTIONS, MAT_MOMENT_DATE_FORMATS, MomentDateAdapter} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';
import * as _moment from 'moment';
import {default as _rollupMoment} from 'moment';
import { AddFieldComponent } from 'src/app/shared/dialogs/add-field/add-field.component';
import { ToastrService } from 'ngx-toastr';
import { UploadService } from 'src/app/services/upload.service';
import { API_ROUTES } from 'src/app/core/_constants/api-route.constant';

const moment = _rollupMoment || _moment;

export const MY_FORMATS = {
  parse: {
    dateInput: 'DD MMMM YYYY',
  },
  display: {
    dateInput: 'DD MMMM YYYY',
    monthYearLabel: 'YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'YYYY',
  },
};

@Component({
  selector: 'app-hr-requirement',
  templateUrl: './hr-requirement.component.html',
  styleUrls: ['./hr-requirement.component.scss'],
  providers:[
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS],
    },

    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS}
  ]
})
export class HrRequirementComponent implements OnInit {
  startDate = new Date();
  hrRequirementForm:any;
  customfields: any=[];
  files: any=[];
//   updateData:any ={
//     "id": "a8ff6adf-3410-4437-bda5-694837abd86c",
//     "auth_id": "bde52cf9-d6c0-4a5e-9742-8a4f64367903",
//     "select_order_req_option": "offering manufacturing service",
//     "title": "manufacturing order req",
//     "description": "enggineering",
//     "location": null,
//     "industry_id": "aff4b12d-8fcc-4695-85e9-2fcbafb8cc4a",
//     "req_shared_id": null,
//     "category1_id": "7d791879-cf85-4f5a-94e2-a6e3cbe995b5",
//     "category2_id": "544d78db-e473-49ca-b07e-03d8dada8f07",
//     "category3_id": null,
//     "no_of_unit": null,
//     "unit_type": "Bottle",
//     "rate": "sqqqdq 122",
//     "lead_time": null,
//     "delivery_details": "asffffff",
//     "payment_term": "google_pay",
//     "experience_needed": "dfd",
//     "salary": "sasd",
//     "joining_date": '2022-06-22T18:30:00.000Z',
//     "notice": "ggrtg",
//     "select_machine_option": null,
//     "capacity": null,
//     "price": null,
//     "urgency": null,
//     "contact": null,
//     "gst": null,
//     "pan": null,
//     "term_condition": null,
//     "req_type": "manufacturing order requirement",
//     "upload_resume": null,
//     "created_at": "2022-06-21T12:19:08.057Z",
//     "updated_at": "2022-06-21T12:19:08.057Z",
//     "deleted_at": null,
//     "Auth": {
//         "id": "bde52cf9-d6c0-4a5e-9742-8a4f64367903",
//         "CompanyInfo": {
//             "id": "f97c765f-dc71-416a-ac5e-312c893cd839",
//             "company_name": "jakkdjk"
//         }
//     },
//     "Media": [
//         {
//             "id": "dd0e4241-5fc9-4e0b-8355-8a38480f6d61",
//             "url": "yahooo.com",
//             "media_type": "video"
//         }
//     ],
//     "Industry": {
//         "id": "c8e184db-9116-4d24-8189-5e3746c41ab2",
//         "industry_name": "Metal Processing"
//     },
//     "Category1": {
//         "id": "7d791879-cf85-4f5a-94e2-a6e3cbe995b5",
//         "title": "Mt cutting"
//     },
//     "Category2": {
//         "id": "544d78db-e473-49ca-b07e-03d8dada8f07",
//         "title": "DRILLING MACHINE"
//     },
//     "Category3": null,
//     "CustomFields": [],
//     "isShownInterest": false,
//     "savedRequirement": false
// }
updateData:any;

  constructor(public dialog:MatDialog,private fb:UntypedFormBuilder,private service:ApiServicesService,
    private toastr:ToastrService,public upload:UploadService) { }

  ngOnInit(): void {
   this.createForm()
    this.requirementDetail();
  }

  get f() { return this.hrRequirementForm.controls; }
    get t() { return this.f.custom_fields as UntypedFormArray; }

    createForm(){
      this.hrRequirementForm = this.fb.group({
        title:['',Validators.required],
      description: [''],
      // industry_id: [''],
      // category1_id: [''],
      // category2_id: [''],
      experience_needed: ['',Validators.required],
      salary: ['',Validators.required],
      joining_date:['',Validators.required],
      notice:['',Validators.required],
      // upload_resume:['',Validators.required],
      req_type:['hr'],
      custom_fields : new UntypedFormArray([])
      })
  
    }

  setDatepicker(){

  }

  requirementDetail(){
    let dataToPost={
      requirement_id:"a8ff6adf-3410-4437-bda5-694837abd86c"
    }
    this.service.get(dataToPost,API_ROUTES.MyRequirements.getRequirementDetail).pipe().subscribe((res=>{
      console.log(res);
      if (res.success) {
        this.updateData = res.result;
        //this.setData();
      this.setCustomfields();
      } else {
        this.toastr.error(res.msg)
      }
    }))
  }

  setCustomfields(){
    if(this.updateData.CustomFields.length > 0){
    for(let i=0; i<this.updateData.CustomFields.length;i++){
      this.t.push(
        this.fb.group({
          lable: this.updateData.CustomFields[i].lable,
          content: this.updateData.CustomFields[i].content
        })
      )
    }
  }
}

  setData(){
    this.hrRequirementForm.patchValue({
      title: this.updateData.title,
    description: this.updateData.description,
    experience_needed: this.updateData.experience_needed,
    salary: this.updateData.salary,
    joining_date:this.updateData.joining_date,
    notice:this.updateData.notice,
    })
  }

  postPublish(form:any){
    const dialogRef = this.dialog.open(PostPublishComponent, {
      maxHeight: '100vh',
      width:'550px',
      data: {
        img:'../../../../assets/images/require.svg',
        // heading:'Post Published',
        title:'Are you sure you want to post this HR requirement?',
        btn:'Yes,Post',
        btnClose : 'Back',
        Close: true
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed', result);
      if(result == true){
        this.service.post(form,API_ROUTES.MyRequirements.createRequirement,{}).pipe().subscribe((res:any)=>{
          console.log(res);
    });
      }
      
    });
  }

  addfield(){
    const dialogRef = this.dialog.open(AddFieldComponent, {
      maxHeight: '100vh',
      width:'550px'
    });
  
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed', result);
        this.customfields.push(result.data);
        console.log(this.customfields);
        this.t.push(
          this.fb.group({
            lable: result.data,
            content: ''
          })
        )
    });
    }
  
    getCustomFieldControls() {
      return this.hrRequirementForm.controls.custom_fields.controls;
    }

    fileupload(e: any) {
      if(this.files.length >0){
        this.toastr.error("More than 1 file is not allowed")
      }
      else{
        const selectedFile = e.target.files[0];
        this.uploadFile(selectedFile);
      }
      return false;
  
    }
  
    async uploadFile(selectedFile : any){
      let uploadedImage:any = await this.upload.uploadFile(selectedFile);
        if (uploadedImage) {
          console.log(uploadedImage);
          this.files.push(uploadedImage);
          
          
          return true;
        } else {
          return false;
        }
    } 
    
    
  updateForm(form:any){
    this.service.put(form,{},API_ROUTES.MyRequirements.updateRequirement).pipe().subscribe((res:any)=>{
      console.log(res);
});
  }  
  
  

}
