import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import { API_ROUTES } from 'src/app/core/_constants/api-route.constant';
import { ApiServicesService } from 'src/app/services/apiServices/api-services.service';
import { EditPopupComponent } from 'src/app/shared/dialogs/edit-popup/edit-popup.component';

@Component({
  selector: 'app-post-detail',
  templateUrl: './post-detail.component.html',
  styleUrls: ['./post-detail.component.scss']
})
export class PostDetailComponent implements OnInit {
  replyComment: any = [];;
  cards=[
    {
    heading:'Unisense Digital Agency',
    min:'27 mins ago',
    para:"Boxboard is a simple and beautiful admin template with tons of flexible components",
    like:'103 Likes',
    comment:'67 Comments',
    share:'105 Share',
    
  
  },

]
  posts=[
    {
      name:'Toni Legros',
      usercomment:'Laborum distinctio autem voluptate dignissimos ut quo',
      reply:'Reply',
      likes:'2 Likes',
      ago:'10s ago'
    },
    {
      name:'Toni Legros',
      usercomment:'Laborum distinctio autem voluptate dignissimos ut quo',
      reply:'Reply',
      likes:'2 Likes',
      ago:'10s ago'
    },
    
  ]
  isShow=false
  data: any;
  details: any;
  public commentList: any[];
  hiddenItems: any={};
  post_id: any;
  isReply:boolean;
  comment: string = '';
  constructor(private dialog:MatDialog, private activeRoute:ActivatedRoute, private service: ApiServicesService) { }
  showdropdown(){
    this.isShow=!this.isShow
  }
  openCollectModal(){
    this.showdropdown();
    const dialogRef = this.dialog.open(EditPopupComponent, {
      maxHeight: '100vh',
      width:'465px',
      data: {
        img:'../.assets/images/report.svg',
        heading:'Are you sure you want to report this comment?',
        para:'Lorem Ipsum is simply dummy text of the printing text of the printing. ',
        report:'Yes, Report',
        cancel:'Cancel'
      }
    });
  }
  ngOnInit(): void {
    this.activeRoute.queryParams.subscribe((params) =>{
      this.post_id = params?.['post_id'];
      console.log(this.post_id);
      this.onUserDetails()
      this.getAllCommentByPostId(this.post_id);

    })
  }
  onUserDetails(){
    this.service.get({post_id:this.post_id},`${API_ROUTES.Post.postDetail}`).pipe().subscribe((res:any)=>{
      this.details = res.result;
      debugger
      console.log(this.details)
    })
  }
  getAllCommentByPostId(data:any){
    var requestBody={
      post_id:data
    }
    this.service.get(requestBody,`${API_ROUTES.Post.postCommentList}`).pipe().subscribe((res)=>{
      if(res.success){
       this.commentList=res.result;
      }else{

      }
    })
  }

  ReplyComment(event:any,data:any,index:any){
    
    this.commentList.forEach(val=>{
      if(val.id==data){
        if( this.isReply==false){
          this.isReply=true;
        }else{
          this.isReply=false;
        }
      }
    });
  }

  sendReplyComment(PostId:any,commentId:any){
    debugger
var requestBody={
post_id:PostId,
comment_id:commentId,
comment_text:this.replyComment[0],
}
if(requestBody.comment_text.trim()!=''||requestBody.comment_text.trim()!=""){
this.service.post(requestBody,`${API_ROUTES.Post.replyComment}`,{}).pipe().subscribe((res)=>{
  if(res.success){
    this.comment = '';
    //this.toastr.success(res.message);
    this.onUserDetails();
  }else{

  }
})
}else{
alert("Please enter the comment");
}
  }

  hitLike(data:any){
    debugger
    var requestBody={
      post_comment_id:data
    }
    this.service.postWithQueryString(requestBody.post_comment_id,`${API_ROUTES.Post.likeComment}`,{}).pipe().subscribe((res)=>{
      if(res.success){
        this.onUserDetails();
        this.getAllCommentByPostId(this.post_id);
      }else{

      }
    })
  }
}
