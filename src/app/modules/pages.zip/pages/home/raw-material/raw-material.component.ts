import { Component, OnInit } from '@angular/core';
import { PostPublishComponent } from 'src/app/shared/dialogs/post-publish/post-publish.component';
import { MatDialog } from '@angular/material/dialog';
import { UntypedFormArray, UntypedFormBuilder, Validators } from '@angular/forms';
import { ApiServicesService } from 'src/app/services/apiServices/api-services.service';
import { API_ROUTES } from 'src/app/core/_constants/api-route.constant';
import { ToastrService } from 'ngx-toastr';
import { AddFieldComponent } from 'src/app/shared/dialogs/add-field/add-field.component';

@Component({
  selector: 'app-raw-material',
  templateUrl: './raw-material.component.html',
  styleUrls: ['./raw-material.component.scss']
})
export class RawMaterialComponent implements OnInit {
  rawMaterialForm:any;
  industrylist: any=[];
  category1List: any=[];
  category2List: any=[];
  customfields: any=[];
  updateData:any ={
    "id": "a8ff6adf-3410-4437-bda5-694837abd86c",
    "auth_id": "bde52cf9-d6c0-4a5e-9742-8a4f64367903",
    "select_order_req_option": "offering manufacturing service",
    "title": "manufacturing order req",
    "description": "enggineering",
    "location": null,
    "industry_id": "aff4b12d-8fcc-4695-85e9-2fcbafb8cc4a",
    "req_shared_id": null,
    "category1_id": "7d791879-cf85-4f5a-94e2-a6e3cbe995b5",
    "category2_id": "ccc99f3a-98ad-4f2d-9544-47335f1d8659",
    "category3_id": null,
    "no_of_unit": null,
    "unit_type": "Bottle",
    "rate": "sqqqdq 122",
    "lead_time": null,
    "delivery_details": "asffffff",
    "payment_term": "google_pay",
    "experience_needed": "dfd",
    "salary": "sasd",
    "joining_date": '2022-06-22T18:30:00.000Z',
    "notice": "ggrtg",
    "select_machine_option": "Sell",
    "capacity": null,
    "price": null,
    "urgency": null,
    "contact": null,
    "gst": null,
    "pan": null,
    "term_condition": null,
    "req_type": "manufacturing order requirement",
    "upload_resume": null,
    "created_at": "2022-06-21T12:19:08.057Z",
    "updated_at": "2022-06-21T12:19:08.057Z",
    "deleted_at": null,
    "Auth": {
        "id": "bde52cf9-d6c0-4a5e-9742-8a4f64367903",
        "CompanyInfo": {
            "id": "f97c765f-dc71-416a-ac5e-312c893cd839",
            "company_name": "jakkdjk"
        }
    },
    "Media": [
        {
            "id": "dd0e4241-5fc9-4e0b-8355-8a38480f6d61",
            "url": "yahooo.com",
            "media_type": "video"
        }
    ],
    "Industry": {
        "id": "c8e184db-9116-4d24-8189-5e3746c41ab2",
        "industry_name": "Metal Processing"
    },
    "Category1": {
        "id": "7d791879-cf85-4f5a-94e2-a6e3cbe995b5",
        "title": "Mt cutting"
    },
    "Category2": {
        "id": "544d78db-e473-49ca-b07e-03d8dada8f07",
        "title": "DRILLING MACHINE"
    },
    "Category3": null,
    "CustomFields": [],
    "isShownInterest": false,
    "savedRequirement": false
}

  constructor(public dialog:MatDialog,private fb:UntypedFormBuilder,private service:ApiServicesService,
    private toastr:ToastrService) { }

  ngOnInit(): void {
    this.rawMaterialForm = this.fb.group({
      title:[''],
    description: [''],
    industry_id: [''],
    category1_id: [''],
    category2_id: [''],
    capacity: [''],
    unit_type: [''],
    price: [''],
    lead_time: [''],
    req_type: ['raw material'],
    custom_fields: new UntypedFormArray([])
    })
    this.industryList();
    
  }

  get f() { return this.rawMaterialForm.controls; }
    get t() { return this.f.custom_fields as UntypedFormArray; }

    setCustomfields(){
      if(this.updateData.CustomFields.length > 0){
      for(let i=0; i<this.updateData.CustomFields.length;i++){
        this.t.push(
          this.fb.group({
            lable: this.updateData.CustomFields[i].lable,
            content: this.updateData.CustomFields[i].content
          })
        )
      }
    }
  }

  requirementDetail(){
    let dataToPost={
      requirement_id:"a8ff6adf-3410-4437-bda5-694837abd86c"
    }
    this.service.get(dataToPost,API_ROUTES.MyRequirements.getRequirementDetail).pipe().subscribe((res=>{
      console.log(res);
      if (res.success) {
        this.updateData = res.result;
        this.setData();
      this.setCustomfields();
        
        
        // this.loader.start();
        
      } else {
        this.toastr.error(res.msg)
      }
      
    }))
  }
    setData(){
      this.rawMaterialForm.patchValue({
        title:this.updateData.title,
    description: this.updateData.description,
    industry_id: this.updateData.industry_id,
    category1_id: this.updateData.category1_id,
    category2_id: this.updateData.category2_id,
    capacity: this.updateData.capacity,
    unit_type: this.updateData.unit_type,
    price: this.updateData.price,
    lead_time: this.updateData.lead_time,
      })
      let category1={
        "target":{
          "value":this.updateData.category1_id
        }
      }
      this.category3(category1)
    }  

  postPublish(form:any){
    //if(form.valid){
      
        
    //}
    const dialogRef = this.dialog.open(PostPublishComponent, {
      maxHeight: '100vh',
      width:'550px',
      data: {
        img:'../../../../assets/images/require.svg',
        // heading:'Post Published',
        title:'Are you sure you want to post this raw material requirement?',
        btn:'Yes,Post',
        btnClose : 'Back',
        Close: true
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed', result);
      if(result == true){
        this.service.post(form,API_ROUTES.MyRequirements.createRequirement,{}).pipe().subscribe((res:any)=>{
          console.log(res);
    })
      }
      
    });
  }

  updateForm(form:any){
    this.service.put(form,{},API_ROUTES.MyRequirements.updateRequirement).pipe().subscribe((res:any)=>{
      console.log(res);
})
  }

  industryList(){
    this.service.get({},API_ROUTES.MyRequirements.industryList).pipe().subscribe((res=>{
      console.log(res);
      if (res.success) {
        this.industrylist = res.result;
        console.log(this.industrylist);
        // this.rawMaterialForm.patchValue({
        //   industry_id:this.updateData.industry_id
        // })
        
        // this.loader.start();
        
      } else {
        this.toastr.error(res.msg)
      }
      
    }))
    this.service.get({},API_ROUTES.MyRequirements.industryCategory1).pipe().subscribe((res=>{
      console.log(res);
      if(res.success){
        this.category1List = res.result.rows;
      }
      else {
        this.toastr.error(res.msg);
      }
      
    }))
    
  }

  category3(event:any){
    let dataToPost = {
      category1_id: event.target.value
    }
    this.service.get(dataToPost,API_ROUTES.MyRequirements.industryCategory2).pipe().subscribe((res=>{
      console.log(res);
      if(res.success){
        this.category2List = res.result.rows;
      }
      else {
        this.toastr.error(res.msg);
      }
      
    }))
  }

  addfield(){
    //   let customfield = {
    //     heading:"A",
    //     name:"B"
    //   }
    //   this.customfields.push(customfield);
    
  
    const dialogRef = this.dialog.open(AddFieldComponent, {
      maxHeight: '100vh',
      width:'550px'
    });
  
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed', result);
      //if(result == "Success"){
        this.customfields.push(result.data);
        
        console.log(this.customfields);
        this.t.push(
          this.fb.group({
            lable: result.data,
            content: ''
          })
        )
        
      //}
      
    });
    }
  
    getCustomFieldControls() {
      return this.rawMaterialForm.controls.custom_fields.controls;
    }

}
