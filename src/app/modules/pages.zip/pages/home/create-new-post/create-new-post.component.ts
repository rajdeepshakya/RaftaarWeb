import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { PostPublishComponent } from 'src/app/shared/dialogs/post-publish/post-publish.component';
import { UploadService } from 'src/app/services/upload.service';
import { ApiServicesService } from 'src/app/services/apiServices/api-services.service';
import { API_ROUTES } from 'src/app/core/_constants/api-route.constant';
import { parse } from 'path';
import { RouteConstant } from 'src/app/core/_constants/route.constant';
import { Router } from '@angular/router';
@Component({
  selector: 'app-create-new-post',
  templateUrl: './create-new-post.component.html',
  styleUrls: ['./create-new-post.component.scss']
})
export class CreateNewPostComponent implements OnInit {
  countnumber:any="";
  contentform:any;
  myForm: UntypedFormGroup;
  submitted = false;
  Media:any=[];
  constructor(private fb:UntypedFormBuilder,
    private dialog :MatDialog,
    public upload: UploadService,
    private toastr:ToastrService,
    private service:ApiServicesService,
    private router: Router,
    ) { }

  files:any = [];
  ngOnInit(): void {
    // this.contentform = this.fb.group({
    //   number:['',Validators.required]
 
    //  });
    this.createForm();
  }
  get f() { return this.myForm.controls; }
   /**createForm*/
   createForm() {
    this.submitted = false;
    this.myForm = this.fb.group({
      content: [null, [Validators.required]],
      location: [null, [Validators.required]],
    })

  }
    postPublish(post:any){
     
      debugger
      var requestBody= {
        media:  [this.Media],
        content:  post.content,
        location: post.location
    }
   
      this.submitted = true;
     
    if (this.myForm.valid) {

      this.service.post(requestBody,`${API_ROUTES.Post.createPost}`,{}).pipe().subscribe(response => {
        debugger
        if (response.success) {
          this.toastr.success(response.message);
          //this.router.navigateByUrl(`/${RouteConstant.home}`);
          this.router.navigate(['/main/home'])
          this.resetFrom();
        } else {
          this.toastr.error(response.message);
        }
       // this.ls.hide();
      }, (err: any) => {
        if (err.error instanceof Error) {
          //this.ls.hide();
          this.toastr.error("Failed");
        } else {
         // this.ls.hide();
          this.toastr.error("Failed");
        }
      });
    }
    }
    

  fileupload(e: any,data:any) {
    debugger
    
    if(this.files.length >5){
      this.toastr.error("More than 5 files are not allowed")
    }
    else {
      if(this.files.length > 0 && (this.files.length + parseInt(e.target.files.length) > 5)){
        this.toastr.error("More than 5 files are not allowed")
      }
      else{
        if(e.target.files.length>1){
          for(let i=0; i<e.target.files.length;i++){
            this.uploadFile(e.target.files[i],data)
          }
         
        }
        else{
          const selectedFile = e.target.files[0];
          this.uploadFile(selectedFile,data);
         
        }
      }
    }
    return false;

  }

  async uploadFile(selectedFile : any,fileTypa:any){
    debugger
    let uploadedImage:any = await this.upload.uploadFile(selectedFile);
      if (uploadedImage) {
        if(fileTypa==1){
          this.Media= {
            url:uploadedImage.Location,
            media_type: "Image",
          }
        }else if(fileTypa==2){
          this.Media= {
            url:uploadedImage.Location,
            media_type: "video",
          }
        }else if(fileTypa==3){
          this.Media= {
            url:uploadedImage.Location,
            media_type: "pdf",
          }
        }
       
        console.log(uploadedImage);
        this.files.push(uploadedImage);
        
        return true;
      } else {

        return false;
      }
  }
  
  /**resetFrom*/
  resetFrom() {
    
    this.submitted = false;
    this.myForm.reset();
  }

}
