import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hr-requirement-list',
  templateUrl: './hr-requirement-list.component.html',
  styleUrls: ['./hr-requirement-list.component.scss']
})
export class HrRequirementListComponent implements OnInit {
  cards=[
    {
    heading:'HR Requirement',
    min:'Jan 22, 2022 at 1:30 PM',
    para:"Boxboard is a simple and beautiful admin template with tons of flexible components",
    like:'103 Likes',
    comment:'67 Comments',
    share:'105 Share',
    
  
  },
  ]
  constructor() { }

  ngOnInit(): void {
  }

}
