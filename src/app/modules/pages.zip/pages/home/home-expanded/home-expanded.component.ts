import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AddNewComponent } from 'src/app/shared/dialogs/add-new/add-new.component';
import { API_ROUTES } from 'src/app/core/_constants/api-route.constant';
import { ApiServicesService } from 'src/app/services/apiServices/api-services.service';
import { AddPostComponent } from 'src/app/shared/dialogs/add-post/add-post.component';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-home-expanded',
  templateUrl: './home-expanded.component.html',
  styleUrls: ['./home-expanded.component.scss']
})
export class HomeExpandedComponent implements OnInit {
cards=[
  {
  heading:'Indus Gears',
  min:'27 mins ago',
  para:"Successfully completed precision gear order for an OEM.",
  like:'103 Likes',
  comment:'67 Comments',
  share:'105 Share',
  name:'Toni Legros',
  usercomment:'Laborum distinctio autem voluptate dignissimos ut quo',
  reply:'Reply',
  likes:'2 Likes',
  ago:'10s ago'
},
]
  homeData: any;
  format: any;
  url: any;
  comment: string = '';
  replyComment: string = '';
  isReply:boolean;
  // showImage:boolean=true;
  // showVideo:boolean=true
  viewer :any;  
  selectedType = 'docx';   
  DemoDoc="http://www.africau.edu/images/default/sample.pdf"  
  constructor(private dialog:MatDialog , private service: ApiServicesService,private router:Router,private toastr:ToastrService) { }
  addPost(){
  const dialogRef = this.dialog.open(AddNewComponent,{
    maxHeight: '100vh',
      width:'501px',
      panelClass:'addNew',
      data: {}
  })
  }
  data: any;
  ngOnInit(): void {
    this.getPost();
  }
  getPost(){
    this.service.get({},`${API_ROUTES.Home.homeListing}`).pipe().subscribe((res)=>{
      debugger
      if(res.success){
        this.data = res.result;
      }else{

      }
     
      // if(res.result.Post!=null){
      //   this.data = res.result.Post;
      //   console.log(this.data,"dfghjkl");
      // }else if(res.result.Requirement!=null)
      // {
      //   this.data = res.result.Requirement;
      // }
      
    }
    )
  }
  likePost(post:any) {
    this.service.post(post,`${API_ROUTES.Post.likePost}`,{}).pipe().subscribe((res)=>{
      if(res.success_code==201){
        alert('password reset successful')
      }
    })
    
  }
  onview(data:any){
    console.log(data,"daataaa")
    this.router.navigate(['/main/home/post-detail'],{queryParams:{post_id:data}})

  }
  navigateOnPost(){
    this.router.navigate(['/main/home/create-new-post']);
  }
    onSelectFile(event:any) {
      const file = event.target.files && event.target.files[0];
      if (file) {
        var reader = new FileReader();
        reader.readAsDataURL(file);
        if(file.type.indexOf('image')> -1){
          this.format = 'image';
          // this.showImage = this.showImage ? false : true;
        } else if(file.type.indexOf('video')> -1){
          this.format = 'video';
          // this.showVideo = this.showVideo ? false : true;
        }
        reader.onload = (event) => {
          this.url = (<FileReader>event.target).result;
        }
      }
    }
    hitLike(data:any){
      var requestBody={
        post_id:data
      }
      this.service.post(requestBody,`${API_ROUTES.Post.likePost}`,{}).pipe().subscribe((res)=>{
        if(res.success){
          this.toastr.success(res.message);
          this.getPost();
        }else{
  
        }
      })
    }
    sendComment(data:any){
      var requestBody={
        post_id:data,
        comment_text:this.comment,
        status:1
      }
      if(this.comment.trim()!=''||this.comment.trim()!=""){
        this.service.post(requestBody,`${API_ROUTES.Post.postComment}`,{}).pipe().subscribe((res)=>{
          if(res.success){
            this.comment = '';
            this.toastr.success(res.message);
            this.getPost();
          }else{
    
          }
        })
      }else{
        alert("Please enter the comment");
      }
      
    }
    ReplyComment(){
      this.isReply=true;
    }
    sendReplyComment(PostId:any,commentId:any){
      debugger
var requestBody={
  post_id:PostId,
  comment_id:commentId,
  comment_text:this.replyComment,
}
if(this.replyComment.trim()!=''||this.replyComment.trim()!=""){
  this.service.post(requestBody,`${API_ROUTES.Post.replyComment}`,{}).pipe().subscribe((res)=>{
    if(res.success){
      this.comment = '';
      this.toastr.success(res.message);
      this.getPost();
    }else{

    }
  })
}else{
  alert("Please enter the comment");
}
    }
    sharePost(data:any){
     
      var requestBody={
        post_id:data
      }
      this.service.post(requestBody,`${API_ROUTES.Post.sharepost}`,{}).pipe().subscribe((res)=>{
        if(res.success){
          this.toastr.success(res.message);
          this.getPost();
        }else{
          this.toastr.error(res.message);
        }
      })
    }
  }

