import { Component, OnInit } from '@angular/core';
import { PostPublishComponent } from 'src/app/shared/dialogs/post-publish/post-publish.component';
import { MatDialog } from '@angular/material/dialog';
import { UntypedFormArray, UntypedFormBuilder, FormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { ApiServicesService } from 'src/app/services/apiServices/api-services.service';
// import * as S3 from 'aws-sdk/clients/s3';
import { environment } from 'src/environments/environment';
import { UploadService } from 'src/app/services/upload.service';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { ToastrService } from 'ngx-toastr';
import { API_ROUTES } from 'src/app/core/_constants/api-route.constant';
import { AddFieldComponent } from 'src/app/shared/dialogs/add-field/add-field.component';
import { Router } from '@angular/router';

@Component({
  selector: 'app-manufacturing-order-requirement',
  templateUrl: './manufacturing-order-requirement.component.html',
  styleUrls: ['./manufacturing-order-requirement.component.scss']
})
export class ManufacturingOrderRequirementComponent implements OnInit {
  mor_form: any;
  submitted: boolean = false;
  imageUrl: any;
  files: any = [];
  imageName: any;
  media: any = [];
  customfields: any = [];
  industrylist: any = [];
  category1List: any = [];
  updateData: any
  //Media:any=[];
  constructor(public dialog: MatDialog,
    private fb: UntypedFormBuilder,
    private service: ApiServicesService,
    public upload: UploadService,
    private loader: NgxUiLoaderService,
    private toastr: ToastrService,
    private router: Router
    ) {

  }
  ngOnInit(): void {
    this.createForm();

    //   {
    //     "title": "manufacturing order req",
    //     "select_order_req_option": "offering manufacturing service",
    //     "description": "enggineering",
    //     "industry_id": "c8e184db-9116-4d24-8189-5e3746c41ab2",
    //     "category1_id": "7d791879-cf85-4f5a-94e2-a6e3cbe995b5",
    //     "category2_id": "544d78db-e473-49ca-b07e-03d8dada8f07",
    //     "rate": "sqqqdq 122",
    //     "unit_type": "Bottle",
    //     "delivery_details": "asffffff",
    //     "payment_term": "google_pay",
    //     "req_type": "manufacturing order requirement",
    //     "media": [
    //         {
    //             "url": "yahooo.com",
    //             "media_type": "video"
    //         }
    //     ],
    //     "custom_fields": [
    //         {
    //             "content": "test",
    //             "lable": "tesrting"
    //         }
    //     ]
    // }

    this.industryList();
    this.requirementDetail();
    this.getCategories();
  }

  createForm() {
    this.mor_form = this.fb.group({
      title: ['', Validators.required],
      select_order_req_option: ['offering manufacturing service', Validators.required],
      description: ['', Validators.required],
      industry_id: ['', Validators.required],
      category1_id: ['', Validators.required],
      rate: ['', Validators.required],
      unit_type: ['', Validators.required],
      delivery_details: ['', Validators.required],
      payment_term: ['', Validators.required],
      req_type: ['manufacturing order requirement', Validators.required],
      custom_fields: new UntypedFormArray([]),
      media:[[], Validators.required],
    });

  }

  setData() {
    this.mor_form.patchValue({
      title: this.updateData.title,
      industry_id: this.updateData.industry_id,
      category1_id: this.updateData.category1_id,
      description: this.updateData.description,
      unit_type: this.updateData.unit_type,
      rate: this.updateData.rate,
      delivery_details: this.updateData.delivery_details,
      payment_term: this.updateData.payment_term,
    })

    this.files = [{ 'Key': "sdsadadsad", "value": "dsfsdf" }]
  }

  setCustomfields() {
    if (this.updateData.CustomFields.length > 0) {
      for (let i = 0; i < this.updateData.CustomFields.length; i++) {
        this.t.push(
          this.fb.group({
            lable: this.updateData.CustomFields[i].lable,
            content: this.updateData.CustomFields[i].content
          })
        )
      }
    }
  }

  requirementDetail() {
    let dataToPost = {
      requirement_id: "a8ff6adf-3410-4437-bda5-694837abd86c"
    }
    this.service.get(dataToPost, API_ROUTES.MyRequirements.getRequirementDetail).pipe().subscribe((res => {
      console.log(res);
      debugger
      if (res.success) {
        this.updateData = res.result;
        console.log("requirementDetail=" + res);
        // this.setData();
        this.setCustomfields();
      } else {
        this.toastr.error(res.msg)
      }

    }))
  }

  get f() { return this.mor_form.controls; }
  get t() { return this.f.custom_fields as UntypedFormArray; }
  get customfieldGroups() {
    return this.t.controls as UntypedFormGroup[];
  }

  postPublish() {
    const dialogRef = this.dialog.open(PostPublishComponent, {
      maxHeight: '100vh',
      width: '550px',
      data: {
        img: '../../../../assets/images/require.svg',
        // heading:'Post Published',
        title: 'Are you sure you want to post this manufacturing order requirement?',
        btn: 'Yes,Post',
        btnClose: 'Back',
        Close: true
      }
    });
  }

  industryList() {
    this.service.get({}, API_ROUTES.MyRequirements.industryList).pipe().subscribe((res => {
      console.log(res);
      debugger
      if (res.success) {
        this.industrylist = res.result;
        console.log("industrylist=" + this.industrylist);
      } else {
        this.toastr.error(res.msg)
      }

    }))

  }
  getCategories() {
    this.service.get({}, API_ROUTES.MyRequirements.industryCategory1).pipe().subscribe((res => {
      console.log(res);
      if (res.success) {
        debugger
        this.category1List = res.result.rows;
        console.log("category1List=" + this.category1List);
      }
      else {
        this.toastr.error(res.msg);
      }

    }))

  }

  submit(body: any) {
    this.submitted = true;
    console.log(this.mor_form.value);
    this.mor_form.value.req_type = "manufacturing order requirement";
    console.log(this.mor_form.value);
    if (this.files.length > 0) {
      for (let i = 0; i < this.files.length; i++) {
        let file = {
          url: this.files[i].Location,
          media_type: this.files[i].type
        }
        this.media.push(file);
      }
      console.log(this.media);
      this.mor_form.value.media = this.media;
    }
    const dialogRef = this.dialog.open(PostPublishComponent, {
      maxHeight: '100vh',
      width: '550px',
      data: {
        img: '../../../../assets/images/require.svg',
        // heading:'Post Published',
        title: 'Are you sure you want to post this manufacturing order requirement?',
        btn: 'Yes,Post',
        btnClose: 'Back',
        Close: true
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed', result);
      if (result == true) {
        debugger
        var data = JSON.stringify(this.mor_form.value);
        console.log("data" + data);
        this.service.post(this.mor_form.value, API_ROUTES.MyRequirements.createRequirement, {}).pipe().subscribe((res) => {
          console.log(res);
          if (res.success_code == 201) {
            this.router.navigate(['/main/home/manufacturing-o-r_home'], { queryParams: { post_id: res.result.id } })
          }
        })
      }

    });

  }

  fileupload(e: any) {
    if (this.files.length > 5) {
      this.toastr.error("More than 5 files are not allowed")
    }
    else {
      if (this.files.length > 0 && (this.files.length + parseInt(e.target.files.length) > 5)) {
        this.toastr.error("More than 5 files are not allowed")
      }
      else if (e.target.files.length > 5) {
        this.toastr.error("More than 5 files are not allowed")
      }
      else {
        if (e.target.files.length > 1) {
          for (let i = 0; i < e.target.files.length; i++) {
            this.uploadFile(e.target.files[i])
          }

        }
        else {
          const selectedFile = e.target.files[0];
          this.uploadFile(selectedFile);
        }
      }
    }
    return false;

  }

  async uploadFile(selectedFile: any) {
    let uploadedImage: any = await this.upload.uploadFile(selectedFile);
    if (uploadedImage) {
      console.log(uploadedImage);
      this.files.push(uploadedImage);
      return true;
    } else {
      return false;
    }
  }

  onFileDropped(file: any) {
    for (let i = 0; i < file.length; i++) {
      this.files.push(file[i].name);
    }
    console.log(this.files);

  }

  addfield() {
    const dialogRef = this.dialog.open(AddFieldComponent, {
      maxHeight: '100vh',
      width: '550px'
    });
    dialogRef.afterClosed().subscribe(result => {
      debugger
      console.log('The dialog was closed', result);
      if (result.data != null) {
        this.customfields.push(result.data);

        console.log(this.customfields);
        this.t.push(
          this.fb.group({
            lable: result.data,
            content: ''
          })
        )
      }
    });
  }

  getCustomFieldControls() {
    return this.mor_form.controls.custom_fields.controls;
  }

  updateForm() {
    this.submitted = true;
    console.log(this.mor_form.value);
    this.mor_form.value.req_type = "manufacturing order requirement";
    console.log(this.mor_form.value);
    if (this.files.length > 0) {
      for (let i = 0; i < this.files.length; i++) {
        let file = {
          url: this.files[i].Location,
          media_type: this.files[i].type
        }
        this.media.push(file);
      }
      console.log(this.media);
      this.mor_form.value.media = this.media;

    }
    this.service.put(this.mor_form.value, {}, API_ROUTES.MyRequirements.updateRequirement).pipe().subscribe((res) => {
      console.log(res);

      if (res.success_code == 201) {
      }
    })
  }

}
