import { Component, OnInit } from '@angular/core';
import { PostPublishComponent } from 'src/app/shared/dialogs/post-publish/post-publish.component';
import { MatDialog } from '@angular/material/dialog';
import { API_ROUTES } from 'src/app/core/_constants/api-route.constant';
import { ApiServicesService } from 'src/app/services/apiServices/api-services.service';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-finance-home',
  templateUrl: './finance-home.component.html',
  styleUrls: ['./finance-home.component.scss']
})
export class FinanceHomeComponent implements OnInit {
  updateData: any;

  constructor(public dialog:MatDialog,private service:ApiServicesService,public toastr:ToastrService) { }

  ngOnInit(): void {
  }

  requirementDetail(){
    let dataToPost={
      requirement_id:"a8ff6adf-3410-4437-bda5-694837abd86c"
    }
    this.service.get(dataToPost,API_ROUTES.MyRequirements.getRequirementDetail).pipe().subscribe((res=>{
      console.log(res);
      if (res.success) {
        this.updateData = res.result;
      //   this.setData();
      // this.setCustomfields();
        
        
        // this.loader.start();
        
      } else {
        this.toastr.error(res.msg)
      }
      
    }))
  }

  deletePost(){
    const dialogRef = this.dialog.open(PostPublishComponent, {
      maxHeight: '100vh',
      width:'550px',
      data: {
        img:'../../../../assets/images/App_icon.svg',
        // heading:'Post Published',
        title:'Hey, do you really want to delete this finance requirement?',
        btn:'Yes,Delete',
        btnClose : 'Go Back',
        Close: true
      }
    });
  }

}
