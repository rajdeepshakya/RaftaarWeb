import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-profile-front-page',
  templateUrl: './profile-front-page.component.html',
  styleUrls: ['./profile-front-page.component.scss']
})
export class ProfileFrontPageComponent implements OnInit {

  constructor(private route:Router) { }

  ngOnInit(): void {
  }
  // projects(){
  //   this.route.navigate(['../layout/profile/products'])
  // }
  about(){
    this.route.navigate(['main/profile/about'])
  }
  projects(){
    this.route.navigate(['main/profile/projects'])
  } 
  product(){
    this.route.navigate(['main/profile/products'])
  }
   instruments(){
    this.route.navigate(['main/profile/instruments'])
  }
}
