import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profileabout',
  templateUrl: './profileabout.component.html',
  styleUrls: ['./profileabout.component.scss']
})
export class ProfileaboutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
