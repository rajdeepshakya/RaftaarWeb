import { Component, Input, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import { OwlOptions } from 'ngx-owl-carousel-o';
import { API_ROUTES } from 'src/app/core/_constants/api-route.constant';
import { ApiServicesService } from 'src/app/services/apiServices/api-services.service';
import { SubjectserviceService } from 'src/app/services/subjectService/subjectservice.service';
import { ShareTestimonialComponent } from 'src/app/shared/dialogs/share-testimonial/share-testimonial.component';
@Component({
  selector: 'app-profileprojectdetail',
  templateUrl: './profileprojectdetail.component.html',
  styleUrls: ['./profileprojectdetail.component.scss']
})

export class ProfileprojectdetailComponent implements OnInit {

  slidesStore: any = [
    
    '../../.assets/images/Rectangle150882.svg',
    '../../.assets/images/Rectangle150882.svg',
    '../../.assets/images/Rectangle150882.svg'
    
  ]


  customOptions: OwlOptions = {
    loop: true,
    mouseDrag: false,
    touchDrag: false,
    pullDrag: false,
    dots: true,
    navSpeed: 700,
    navText: ['', ''],
    responsive: {
      0: {
        items: 1
      },
      400: {
        items: 2
      },
      740: {
        items: 3
      },
      940: {
        items: 1
      }
    },
    nav: false,
  }
  projectsName:any;
  projectId: any;
  Highlights: any;
  updateUserInfo: any;
  constructor(private dialog:MatDialog,private subjectService:SubjectserviceService,
    private service :ApiServicesService,
    private activeRoute: ActivatedRoute) { }

  openShareTestimonial(){
    const dialogRef = this.dialog.open(ShareTestimonialComponent, {
      maxHeight: '100vh',
      width:'465px',
      panelClass:'ShareTestimonial',
      data: {
      }
    });
  }
  ngOnInit(): void {
    this.activeRoute.queryParams.subscribe((params) =>{
      this.projectId = params?.['projectId'];
      console.log(this.projectId)


    })
    this.onUserDetails();
    this.subjectService.getNewUserInfo().subscribe(info => {
      this.updateUserInfo = info;
    })
  }
  onUserDetails(){
    this.service.get({projectId:this.projectId},`${API_ROUTES.Projects.projectsDetail}`).pipe().subscribe((res)=>{
      this.projectsName = res.result;
      this.Highlights=res.result.Highlights
      console.log(this.projectsName)
    })
  }

  onUserDelete(){
    this.service.delete({user_id:this.projectId},`${API_ROUTES.More.userDelete}`).pipe().subscribe((res)=>{
      this.projectsName = res.result;
      console.log(this.projectsName)
    })
  }
}
