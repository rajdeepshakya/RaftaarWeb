import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { API_ROUTES } from 'src/app/core/_constants/api-route.constant';
import { ApiServicesService } from 'src/app/services/apiServices/api-services.service';
import { LocalStorageProvider } from 'src/app/services/storage/storage.service';
import { AddNewComponent } from 'src/app/shared/dialogs/add-new/add-new.component';

@Component({
  selector: 'app-profile-instruments',
  templateUrl: './profile-instruments.component.html',
  styleUrls: ['./profile-instruments.component.scss']
})
export class ProfileInstrumentsComponent implements OnInit {
  cards=[
    {
    heading:'Instrument / Machine Name',
    min:'Content here',
    },
    {
      heading:'Instrument / Machine Name',
      min:'Content here',
      },
  ]
  isShow=false
  data: any;
  machineId: any;

  constructor(private dialog :MatDialog,private activeRoute:ActivatedRoute,private service:ApiServicesService,private router :Router,private storageService: LocalStorageProvider) { }
  showdropdown(){
    this.isShow=!this.isShow
  }
  openAddNew(){
    const dialogRef = this.dialog.open(AddNewComponent, {
      maxHeight: '100vh',
      width:'501px',
      panelClass:'addNew',
      data: {

      }
    });
  }
  ngOnInit(): void {
    this.activeRoute.queryParams.subscribe((params) =>{
      this.machineId = params?.['id'];
      // console.log(this.machineId)
      this.getIndustry()
     
    })
  }
 
  getIndustry(){
    let dataPost={
      type:'machine'
    }
    this.service.get(dataPost,`${API_ROUTES.Machine.machineList}`).pipe().subscribe((res)=>{
      this.data = res.result;
      console.log(this.data)
    })
    let datainstrument={
      type:'instrument'
    }
    this.service.get(datainstrument,`${API_ROUTES.Machine.instrumentList}`).pipe().subscribe((res)=>{
      this.data = res.result;
      console.log(this.data)
    })
}
edit(id:any){
  this.router.navigate(['/main/profile/newMachine/edit-machine'],{queryParams:{id:id}})
}
machineDelete(id:any){
  this.service.delete({id:id},`${API_ROUTES.Machine.deleteMachine}`).pipe().subscribe((res)=>{
    if(res.success_code==201){
      alert('Deleted successfully');
      let dataPost={
        type:'machine'
      }
      this.service.get(dataPost,`${API_ROUTES.Machine.machineList}`).pipe().subscribe((res)=>{
        this.data = res.result;
        console.log(this.data)
      })
      let datainstrument={
        type:'instrument'
      }
      this.service.get(datainstrument,`${API_ROUTES.Machine.instrumentList}`).pipe().subscribe((res)=>{
        this.data = res.result;
        console.log(this.data)
      })
      }
  })
}
}
