import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AnyNaptrRecord } from 'dns';
import { API_ROUTES } from 'src/app/core/_constants/api-route.constant';
import { ApiServicesService } from 'src/app/services/apiServices/api-services.service';
import { LocalStorageProvider } from 'src/app/services/storage/storage.service';

@Component({
  selector: 'app-profileprojects',
  templateUrl: './profileprojects.component.html',
  styleUrls: ['./profileprojects.component.scss']
})
export class ProfileprojectsComponent implements OnInit {
  cards=[
    {
    heading:'Unisense Digital Agency',
    min:'27 mins ago',
    para:"Boxboard is a simple and beautiful admin template with tons of flexible components",
    },
    {
      heading:'Unisense Digital Agency',
      min:'27 mins ago',
      para:"Boxboard is a simple and beautiful admin template with tons of flexible components",
      },
]
  projectId: any;
constructor(private service:ApiServicesService,private activeRoute:ActivatedRoute, private storage:LocalStorageProvider, private router:Router) { }
interestName:any =[];
ngOnInit(): void {
  this.activeRoute.queryParams.subscribe((params) =>{
    this.projectId = params?.['id'];
    // console.log(this.machineId)
   
  })
  this.onUserList();
}
onUserList(){
  let dataPost={
   size :'20'
  }
  this.service.get(dataPost,`${API_ROUTES.Projects.projectsList}`).pipe().subscribe((res)=>{
    this.interestName = res.result;
  })
}
onview(data:any){
  this.router.navigate(['main/profile/profile-project-detail'],{queryParams:{projectId:data}})

}
edit(id:any){
  this.router.navigate(['/main/profile/newProjects/edit-project'],{queryParams:{id:id}})
  }
  projectDelete(id:any){
    this.service.delete({project_id:id},`${API_ROUTES.Projects.deleteProject}`).pipe().subscribe((res)=>{
      if(res.success_code==201){
        alert('Deleted successfully');
          let dataPost={
           size :'20'
          }
          this.service.get(dataPost,`${API_ROUTES.Projects.projectsList}`).pipe().subscribe((res)=>{
            this.interestName = res.result;
          })
        }
      
    })
  }
}
