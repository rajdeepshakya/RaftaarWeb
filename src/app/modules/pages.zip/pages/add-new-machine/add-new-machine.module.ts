import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';

import { AddNewMachineRoutingModule } from './add-new-machine-routing.module';
import { AddNewMachineComponent } from './add-new-machine/add-new-machine.component';
import { EditMachineComponent } from './edit-machine/edit-machine.component';
import { LayoutModule } from 'src/app/layout/layout.module';
import { ReactiveFormsModule } from '@angular/forms';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';


@NgModule({
  declarations: [
    AddNewMachineComponent,
    EditMachineComponent
  ],
  imports: [
    CommonModule,
    AddNewMachineRoutingModule,
    LayoutModule,
    ReactiveFormsModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSelectModule,
    MatFormFieldModule,

  ],
  providers: [DatePipe]

})
export class AddNewMachineModule { }
