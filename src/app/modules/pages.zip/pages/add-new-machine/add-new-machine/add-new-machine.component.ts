import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { API_ROUTES } from 'src/app/core/_constants/api-route.constant';
import { ApiServicesService } from 'src/app/services/apiServices/api-services.service';
import { LocalStorageProvider } from 'src/app/services/storage/storage.service';
import { EditPopupComponent } from 'src/app/shared/dialogs/edit-popup/edit-popup.component';
import { resourceLimits } from 'worker_threads';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-add-new-machine',
  templateUrl: './add-new-machine.component.html',
  styleUrls: ['./add-new-machine.component.scss']
})
export class AddNewMachineComponent implements OnInit {
  machineForm:any
  submitted: boolean=false;
  editData: any;
  constructor(public datepipe:DatePipe,private dialog:MatDialog, private fb:FormBuilder,private service:ApiServicesService,private router :Router,private localService:LocalStorageProvider) { }

  ngOnInit(): void {
    this.machineForm=this.fb.group({
      name:['',[Validators.required]],
      type:['',[Validators.required]],
      make:['',[Validators.required]],
      capacity:['',[Validators.required]],
      quantity:['',[Validators.required]]

    })
  }
  openpostModal(){
    const dialogRef = this.dialog.open(EditPopupComponent, {
      maxHeight: '100vh',
      width:'465px',
      panelClass:'yespost',
      data: {
        img:'../.assets/images/Icon.png',
        heading:'Are you sure you want to post this machine?',
        para:'Lorem Ipsum is simply dummy text of the printing text of the printing. ',
        report:'Back',
        cancel:'Yes, Post'
      }
    });
  }
  get f() { return this.machineForm.controls; }

  onSubmit(data:any){
    let machineDate=this.datepipe.transform(data.make,'yyyy/MM/dd');
    data.make=machineDate
    console.log(data,"addMachine");
    this.submitted = true;
    this.service.post(data,`${API_ROUTES.Machine.createMachine}`,{}).pipe().subscribe((res)=>{
        // this.localService.setItem('machineId',res.result.id)
      if(res.success_code==201){
        alert("Success");
        let id=res.result.id
        this.router.navigate(['/main/profile/instruments'],{queryParams:{id:id}})

      }
      
    })}
//    patchData() {
//     console.log(this.editData)
//     this.machineForm.patchValue({
//       name: this.editData.name,
//       title: this.editData.title,
//       type:this.editData.type,
//       capacity:this.editData.capacity,
//       quantity:this.editData.quantity

      
//     });
// }



}
